<html><head><title>Vuln Scripts</title></head>
<body>
<h2>Injection Examples</h2>
<ul>
<li><a href="sqli.php">SQL Injection</a></li>
<li><a href="commandinj.php?command=ls">Command Injection</a></li>
</ul>
<h2>Web Services</h2>
<ul>
<li><a href="webservices-standalone/ws-helloWorld.php">Hello World WebService</a></li>
<li><a href="webservices-standalone/ws-commandinj.php">Command Injection WebService</a></li>
<li><a href="webservices-standalone/ws-sqli.php">SQLi WebServices</a></li>
</ul>
</body>
</html>


